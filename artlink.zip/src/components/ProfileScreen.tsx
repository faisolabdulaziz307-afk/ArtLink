import React, { useState, useEffect, useRef } from 'react';
import { Menu, Star, Grid, Palette, Camera, Mail, Sparkles, MessageSquare, Send, CheckCheck, Compass, Heart } from 'lucide-react';
import { UserProfile, Artwork, Message } from '../types';
import { MOCK_BOT_RESPONSES } from '../data';

interface ProfileScreenProps {
  designer: UserProfile;
  artworks: Artwork[];
  onArtClick: (artwork: Artwork) => void;
  onGoToExplore: () => void;
  onShowToast: (message: string) => void;
}

export default function ProfileScreen({ designer, artworks, onArtClick, onGoToExplore, onShowToast }: ProfileScreenProps) {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Message[]>([
    { id: '1', sender: 'andra', text: 'Halo! Saya Andra. Terima kasih sudah mampir di profil Artlink saya. Ada konsep desain seru yang ingin Anda diskusikan?', timestamp: 'Sekarang' }
  ]);
  const [inputText, setInputText] = useState('');
  const [isAndraTyping, setIsAndraTyping] = useState(false);
  
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Filter artworks owned by Andra Ramadhan
  const andraArtworks = artworks.filter(art => art.artist.name === designer.name);

  // Specific 1 big featured and 2 minor grid layouts according to Screenshot 2
  const etherealArt = andraArtworks.find(art => art.title === "Ethereal Interface") || andraArtworks[0];
  const neonPrismArt = andraArtworks.find(art => art.title === "Neon Prism") || andraArtworks[1];
  const darkNebulaArt = andraArtworks.find(art => art.title === "Nebula City" || art.title === "Dark Nebula") || andraArtworks[2];

  // Scroll mock chat to bottom
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isAndraTyping]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputText,
      timestamp: 'Baru saja'
    };

    setChatMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsAndraTyping(true);

    // Simulate Andra replying with creativity
    setTimeout(() => {
      setIsAndraTyping(false);
      const randomIndex = Math.floor(Math.random() * MOCK_BOT_RESPONSES.length);
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'andra',
        text: MOCK_BOT_RESPONSES[randomIndex],
        timestamp: 'Baru saja'
      };
      setChatMessages(prev => [...prev, botMsg]);
    }, 1500);
  };

  const handleSocialClick = (platform: string, desc: string) => {
    onShowToast(`Membuka tautan ${platform} desainer Andra Ramadhan...`);
  };

  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#051424] text-slate-100 pb-28 scrollbar-none select-none">
      
      {/* Background Soft Purple Glow */}
      <div className="absolute top-10 left-[50%] -translate-x-[50%] w-60 h-60 bg-violet-600/15 rounded-full blur-[80px] pointer-events-none"></div>

      {/* 1. Header (Same as exact image layout 2) */}
      <div className="sticky top-0 w-full px-5 py-3 bg-[#051424]/85 backdrop-blur-md border-b border-white/5 z-20 flex justify-between items-center bg-slate-950/40">
        <div className="flex items-center gap-3">
          <button className="text-slate-300 hover:text-white transition-all">
            <Menu className="w-5.5 h-5.5" />
          </button>
          <span className="font-extrabold text-xl bg-gradient-to-r from-violet-400 to-fuchsia-300 bg-clip-text text-transparent">
            Artlink
          </span>
        </div>
        
        {/* User preview header round button */}
        <div className="w-8 h-8 rounded-full border border-violet-500/50 overflow-hidden bg-slate-800">
          <img 
            src={designer.avatar} 
            alt="Andra Ramadhan Avatar" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Profile Details Container */}
      <div className="px-5 pt-6 flex flex-col items-center">
        
        {/* Glowing Profile Avatar with connection Indicator */}
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full p-[3px] bg-gradient-to-tr from-violet-500 to-fuchsia-400 shadow-[0_0_25px_rgba(167,139,250,0.35)]">
            <div className="w-full h-full rounded-full overflow-hidden bg-slate-950 border border-[#051424]">
              <img 
                src={designer.avatar} 
                alt={designer.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          {/* Green Online Dot */}
          <div className="absolute bottom-1 right-2.5 w-4 h-4 bg-emerald-500 rounded-full border-3 border-[#051424] flex items-center justify-center shadow-lg">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-100 animate-pulse"></div>
          </div>
        </div>

        {/* Name and headline biography */}
        <h2 className="text-xl font-bold tracking-tight text-white mb-2 text-center">{designer.name}</h2>
        <p className="text-xs text-slate-300 leading-relaxed text-center font-normal px-4 max-w-[325px] mb-4.5">
          {designer.bio}
        </p>

        {/* Skill badges Row (Capsule size styled) */}
        <div className="flex items-center gap-1.5 mb-6">
          {designer.tags.map(tag => (
            <span key={tag} className="text-[9px] font-black tracking-widest text-[#d2bbff] bg-[#122131]/80 border border-white/5 py-1 px-3 rounded-full uppercase">
              {tag}
            </span>
          ))}
        </div>

        {/* Contact Designer Pill Button */}
        <button
          onClick={() => setIsChatOpen(true)}
          className="w-full max-w-[320px] py-3.5 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wider shadow-lg shadow-violet-600/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer mb-8"
        >
          <MessageSquare className="w-4 h-4 text-violet-200" />
          Hubungi Desainer
        </button>

        {/* Custom SOCIAL PRESENCE menu */}
        <div className="w-full mb-8">
          <p className="text-[10px] font-bold text-slate-500 tracking-wider mb-3 uppercase pl-1">
            Social Presence
          </p>
          <div className="grid grid-cols-4 gap-3">
            <button 
              onClick={() => handleSocialClick('Dashboard', 'Semua Portofolio')}
              className="aspect-square rounded-2xl bg-[#122131]/50 border border-white/5 hover:bg-[#122131]/80 active:scale-95 transition-all flex flex-col items-center justify-center text-slate-400 hover:text-violet-300 cursor-pointer"
            >
              <Grid className="w-5 h-5 mb-1 text-slate-300" />
            </button>
            
            <button 
              onClick={() => handleSocialClick('Dribbble', 'Inspirasi Warna')}
              className="aspect-square rounded-2xl bg-[#122131]/50 border border-white/5 hover:bg-[#122131]/80 active:scale-95 transition-all flex flex-col items-center justify-center text-slate-400 hover:text-pink-400 cursor-pointer"
            >
              <Palette className="w-5 h-5 mb-1 text-slate-300" />
            </button>

            <button 
              onClick={() => handleSocialClick('Instagram', 'Galeri Sosial')}
              className="aspect-square rounded-2xl bg-[#122131]/50 border border-white/5 hover:bg-[#122131]/80 active:scale-95 transition-all flex flex-col items-center justify-center text-slate-400 hover:text-amber-400 cursor-pointer"
            >
              <Camera className="w-5 h-5 mb-1 text-slate-300" />
            </button>

            <button 
              onClick={() => {
                onShowToast("Menyalin email desainer Andra Ramadhan: andra@artlink.design");
              }}
              className="aspect-square rounded-2xl bg-[#122131]/50 border border-white/5 hover:bg-[#122131]/80 active:scale-95 transition-all flex flex-col items-center justify-center text-slate-400 hover:text-teal-400 cursor-pointer"
            >
              <Mail className="w-5 h-5 mb-1 text-slate-300" />
            </button>
          </div>
        </div>

        {/* Portfolio Area Section */}
        <div className="w-full space-y-4">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-base font-extrabold text-white tracking-tight">Portofolio</h3>
            <button 
              onClick={onGoToExplore}
              className="text-[9px] font-black text-violet-400 tracking-wider hover:underline"
            >
              LIHAT SEMUA
            </button>
          </div>

          {/* Master featured item card (Ethereal Interface) */}
          {etherealArt && (
            <div 
              onClick={() => onArtClick(etherealArt)}
              className="relative w-full rounded-3xl overflow-hidden border border-white/[0.08] shadow-lg cursor-pointer transition-all duration-350 hover:scale-[1.01] hover:border-violet-500/25"
            >
              <div className="aspect-[16/10] w-full bg-slate-950">
                <img 
                  src={etherealArt.image} 
                  alt={etherealArt.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/10 to-transparent"></div>
              
              <div className="absolute bottom-4 left-4 right-4">
                <h4 className="text-sm font-bold text-white tracking-tight">{etherealArt.title}</h4>
                <p className="text-[10px] text-violet-300 font-semibold uppercase tracking-wider mt-0.5">
                  {etherealArt.category} • 2024
                </p>
              </div>
            </div>
          )}

          {/* Double small tiles layout underneath (Neon Prism & Dark Nebula) */}
          <div className="grid grid-cols-2 gap-3.5">
            {/* Neon Prism item */}
            {neonPrismArt && (
              <div 
                onClick={() => onArtClick(neonPrismArt)}
                className="relative aspect-square rounded-2xl overflow-hidden border border-white/[0.08] shadow-md cursor-pointer transition-all hover:scale-[1.02]"
              >
                <img 
                  src={neonPrismArt.image} 
                  alt={neonPrismArt.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/10 to-transparent"></div>
                <div className="absolute bottom-2.5 left-2.5 right-2.5">
                  <h5 className="text-[10px] font-bold text-white leading-tight truncate">{neonPrismArt.title}</h5>
                </div>
              </div>
            )}

            {/* Dark Nebula item */}
            {darkNebulaArt && (
              <div 
                onClick={() => onArtClick(darkNebulaArt)}
                className="relative aspect-square rounded-2xl overflow-hidden border border-white/[0.08] shadow-md cursor-pointer transition-all hover:scale-[1.02]"
              >
                <img 
                  src={darkNebulaArt.image} 
                  alt={darkNebulaArt.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/10 to-transparent"></div>
                <div className="absolute bottom-2.5 left-2.5 right-2.5">
                  <h5 className="text-[10px] font-bold text-white leading-tight truncate">{darkNebulaArt.title}</h5>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* --- FLOATING CHAT SCREEN MODAL overlay with ANDRA --- */}
      {isChatOpen && (
        <div className="absolute inset-0 bg-[#020617]/95 z-50 flex flex-col justify-end">
          
          <div className="w-full h-[85%] bg-[#0d1624] border-t border-white/10 rounded-t-[32px] flex flex-col overflow-hidden relative shadow-2xl">
            
            {/* Chat header */}
            <div className="px-5 py-4.5 bg-[#122131]/60 border-b border-white/10 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <img 
                    src={designer.avatar} 
                    alt="Andra Ramadhan Avatar" 
                    className="w-9 h-9 rounded-full object-cover border border-violet-500/20"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-0 right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-[#0d1624]"></div>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1">
                    {designer.name} 
                    <Sparkles className="w-3 h-3 text-violet-400" />
                  </h4>
                  <p className="text-[9px] text-emerald-400 font-semibold uppercase tracking-wider">Aktif Berdiskusi</p>
                </div>
              </div>
              
              <button 
                onClick={() => setIsChatOpen(false)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
              >
                <XIcon className="w-4 h-4 text-slate-300" />
              </button>
            </div>

            {/* Chat discussion history list */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 scrollbar-none">
              {chatMessages.map((msg) => {
                const isAndra = msg.sender === 'andra';
                return (
                  <div 
                    key={msg.id}
                    className={`flex ${isAndra ? 'justify-start' : 'justify-end'} w-full items-end gap-1.5`}
                  >
                    {isAndra && (
                      <img 
                        src={designer.avatar} 
                        alt="Andra Avatar" 
                        className="w-6 h-6 rounded-full object-cover mb-1" 
                        referrerPolicy="no-referrer"
                      />
                    )}
                    <div className="max-w-[80%] flex flex-col">
                      <div className={`p-3.5 rounded-2xl text-xs font-medium leading-relaxed shadow-lg ${
                        isAndra 
                          ? 'bg-[#122131] border border-white/5 text-slate-200 rounded-bl-xs' 
                          : 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white rounded-br-xs'
                      }`}>
                        {msg.text}
                      </div>
                      <span className={`text-[8px] text-slate-500 mt-1 flex items-center gap-0.5 ${isAndra ? 'self-start pl-1' : 'self-end pr-1'}`}>
                        {msg.timestamp}
                        {!isAndra && <CheckCheck className="w-3 h-3 text-violet-400 inline" />}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* simulated Typing indicator */}
              {isAndraTyping && (
                <div className="flex justify-start w-full items-end gap-1.5">
                  <img 
                    src={designer.avatar} 
                    alt="Andra Avatar" 
                    className="w-6 h-6 rounded-full object-cover mb-1" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="p-3.5 rounded-2xl bg-[#122131] border border-white/5 text-slate-400 rounded-bl-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce delay-150"></span>
                    <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce delay-300"></span>
                  </div>
                </div>
              )}
              
              <div ref={chatBottomRef} />
            </div>

            {/* Quick pre-set questions suggestion buttons row */}
            <div className="px-4 py-2 border-t border-white/5 bg-[#0b121e]/80 flex gap-2 overflow-x-auto scrollbar-none whitespace-nowrap">
              {['Bisa kolaborasi proyek?', 'Bagaimana lisensi karyanya?', 'Berapa rate jasanya?'].map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setInputText(p);
                  }}
                  className="px-3 py-1.5 bg-slate-800/60 hover:bg-slate-800 border border-white/10 rounded-full text-[10px] font-bold text-violet-300 active:scale-95 transition-all text-xs cursor-pointer"
                >
                  {p}
                </button>
              ))}
            </div>

            {/* User message edit and send box */}
            <div className="px-4 py-3 bg-[#121c2c] border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Diskusikan proyek Anda..."
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 bg-slate-900 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500/60"
              />
              <button
                onClick={handleSendMessage}
                className="w-11 h-11 bg-gradient-to-r from-violet-600 to-indigo-600 text-white rounded-2xl flex items-center justify-center transition-all hover:opacity-95 active:scale-95 shrink-0 cursor-pointer"
              >
                <Send className="w-4 h-4 ml-0.5" />
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}

// Micro local helper to resolve circular close icons without naming duplication
function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  );
}
