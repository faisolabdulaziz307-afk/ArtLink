import { Compass, PlusCircle, User, Briefcase } from 'lucide-react';

interface BottomNavbarProps {
  currentTab: 'explore' | 'upload' | 'profile';
  setTab: (tab: 'explore' | 'upload' | 'profile') => void;
  avatarUrl: string;
}

export default function BottomNavbar({ currentTab, setTab, avatarUrl }: BottomNavbarProps) {
  const tabs = [
    { id: 'explore' as const, label: 'Eksplor', icon: Compass },
    { id: 'upload' as const, label: 'Unggah', icon: PlusCircle },
    { id: 'profile' as const, label: 'Profil Andra', icon: User },
  ];

  return (
    <div className="absolute bottom-5 inset-x-4 h-16 bg-slate-900/60 backdrop-blur-[30px] rounded-full border border-white/10 flex items-center justify-around px-4 shadow-[0_15px_30px_rgba(0,0,0,0.5),_0_1px_15px_rgba(124,58,237,0.15)] z-40">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;

        return (
          <button
            key={tab.id}
            id={`nav-btn-${tab.id}`}
            onClick={() => setTab(tab.id)}
            className="relative flex flex-col items-center justify-center py-2 px-3.5 rounded-full transition-all duration-300 group"
          >
            {/* Minimal Icon Glow on Active */}
            <div className={`p-1 rounded-full transition-all duration-300 relative ${
              isActive 
                ? 'text-violet-400 scale-110' 
                : 'text-slate-400 group-hover:text-slate-200'
            }`}>
              <Icon className="w-5.5 h-5.5 transition-transform" />
              {isActive && (
                <div className="absolute inset-0 bg-violet-500/35 blur-md rounded-full -z-10 animate-pulse"></div>
              )}
            </div>

            {/* Micro Dot / Label at the bottom */}
            <span className={`text-[9px] font-semibold tracking-wider uppercase transition-all duration-300 ${
              isActive 
                ? 'text-violet-300 mt-0.5 max-h-4 opacity-100' 
                : 'text-slate-500 max-h-0 opacity-0 overflow-hidden'
            }`}>
              {tab.label}
            </span>

            {/* Glowing Accent Underline */}
            {isActive && (
              <div className="absolute bottom-1 w-4 h-[2px] bg-violet-400 rounded-full shadow-[0_0_8px_rgba(167,139,250,1)]"></div>
            )}
          </button>
        );
      })}
    </div>
  );
}
