import React, { useState } from 'react';
import { Mail, Lock, Sparkles, LogIn } from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (email: string) => void;
  onBackToLanding: () => void;
}

export default function LoginScreen({ onLoginSuccess, onBackToLanding }: LoginScreenProps) {
  const [email, setEmail] = useState('andra@artlink.design');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Email wajib diisi.');
      return;
    }
    if (!password || password.length < 5) {
      setError('Kata sandi harus minimal 5 karakter.');
      return;
    }

    setIsLoading(true);

    // Simulate standard network delay the premium way
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess(email);
    }, 1000);
  };

  const toggleAuthMode = () => {
    setIsRegisterMode(!isRegisterMode);
    setError('');
  };

  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#051424] text-slate-100 flex flex-col justify-center px-5 py-6 select-none scrollbar-none">
      
      {/* Background Neon Blur Ambient Glow */}
      <div className="absolute -top-12 -left-12 w-48 h-48 bg-violet-600/10 rounded-full blur-[80px] pointer-events-none"></div>
      <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-indigo-500/10 rounded-full blur-[80px] pointer-events-none"></div>

      {/* Floating back to welcome screen arrow */}
      <button 
        onClick={onBackToLanding}
        className="absolute top-4 left-4 text-xs font-semibold text-slate-400 hover:text-white flex items-center gap-1 bg-slate-900/40 px-3 py-1.5 rounded-full border border-white/5 transition-all cursor-pointer"
      >
        ← Kembali
      </button>

      {/* Main Glass Card Frame modeled exactly after screenshot 1 */}
      <div className="w-full bg-[#122131]/60 backdrop-blur-[24px] border border-white/10 rounded-[32px] p-6 shadow-[0_20px_40px_rgba(0,0,0,0.5)]">
        
        {/* Brand Text Header */}
        <div className="text-center mb-5">
          <h1 className="text-2xl font-black bg-gradient-to-r from-violet-300 via-fuchsia-300 to-indigo-300 bg-clip-text text-transparent tracking-tight">
            Artlink
          </h1>
        </div>

        {/* Welcome titles */}
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold tracking-tight text-white mb-1.5">
            {isRegisterMode ? 'Buat Akun Anda' : 'Selamat Datang'}
          </h2>
          <p className="text-xs text-slate-400">
            {isRegisterMode ? 'Daftar sekarang untuk mengunggah karya terbaik' : 'Silakan masuk ke akun Anda'}
          </p>
        </div>

        {/* Social Logins Row */}
        <div className="grid grid-cols-2 gap-3.5 mb-5">
          <button 
            type="button"
            onClick={() => onLoginSuccess('google.user@gmail.com')}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] active:scale-95 border border-white/10 text-xs font-semibold text-white/95 transition-all cursor-pointer"
          >
            {/* Custom Google lens representation */}
            <span className="w-4 h-4 rounded-full bg-red-500/80 flex items-center justify-center text-[8px] font-black font-mono text-white shadow-sm shrink-0">
              G
            </span>
            Google
          </button>
          
          <button 
            type="button"
            onClick={() => onLoginSuccess('apple.user@icloud.com')}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] active:scale-95 border border-white/10 text-xs font-semibold text-white/95 transition-all cursor-pointer"
          >
            {/* Apple custom code logo representation */}
            <span className="w-4 h-4 rounded-full bg-slate-800 flex items-center justify-center text-[7px] font-bold text-slate-300 shrink-0">
              iOS
            </span>
            Apple
          </button>
        </div>

        {/* Separator block "ATAU" */}
        <div className="relative flex py-2 items-center mb-5">
          <div className="flex-grow border-t border-white/10"></div>
          <span className="flex-shrink mx-4 text-[10px] font-bold text-slate-500 tracking-widest uppercase">
            atau
          </span>
          <div className="flex-grow border-t border-white/10"></div>
        </div>

        {/* Core Email and Password Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Email input block */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5 pl-1">
              EMAIL
            </label>
            <div className="relative">
              <input
                id="login-email-input"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@email.com"
                className="w-full bg-[#051424]/90 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500/80 transition-all font-medium"
              />
              <Mail className="absolute right-4 top-3.5 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </div>

          {/* Password block */}
          <div>
            <div className="flex justify-between items-center mb-1.5 pl-1">
              <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase">
                KATA SANDI
              </label>
              <button
                type="button"
                onClick={() => alert("Lupa sandi? Reset link disimulasikan terkirim ke email Anda.")}
                className="text-[10px] font-extrabold text-violet-400 hover:text-violet-350 transition-colors"
              >
                Lupa Sandi?
              </button>
            </div>
            
            <div className="relative">
              <input
                id="login-password-input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-[#051424]/90 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500/80 transition-all font-medium"
              />
              <Lock className="absolute right-4 top-3.5 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </div>

          {/* Error display */}
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-[11px] text-center font-semibold">
              ⚠️ {error}
            </div>
          )}

          {/* Submit button: Masuk Sekarang / Daftar */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-6 mt-4 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-60 text-white font-bold text-xs tracking-wide shadow-lg shadow-violet-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <span className="flex items-center gap-1.5">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Menghubungkan...
              </span>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                {isRegisterMode ? 'Daftar Sekarang' : 'Masuk Sekarang'}
              </>
            )}
          </button>
        </form>

        {/* Toggle option Footer */}
        <div className="text-center mt-5">
          <button 
            type="button" 
            onClick={toggleAuthMode}
            className="text-[11px] text-slate-400 hover:text-white transition-colors"
          >
            {isRegisterMode ? 'Sudah punya akun? ' : 'Belum punya akun? '}
            <span className="font-extrabold text-violet-400 underline">
              {isRegisterMode ? 'Masuk' : 'Daftar'}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
}
