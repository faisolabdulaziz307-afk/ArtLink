import React, { useState, useRef } from 'react';
import { Menu, UploadCloud, FileImage, Sparkles, CheckCircle2, ChevronDown, Trash2 } from 'lucide-react';
import { Artwork } from '../types';

interface UploadScreenProps {
  onPublishArtwork: (newArt: Omit<Artwork, 'id' | 'likes' | 'liked' | 'views' | 'timestamp'>) => void;
  userAvatar: string;
}

export default function UploadScreen({ onPublishArtwork, userAvatar }: UploadScreenProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('3D Art');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [tagsInput, setTagsInput] = useState('Concept, Digital, Creative');
  const [isDragging, setIsDragging] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Trigger file dialog
  const handleSelectFileClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Drag and Drop simulation
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Simulation Helper to generate beautiful random visual mockup to bypass manual selection
  const handleSimulateArt = () => {
    const defaultMocks = [
      {
        title: "Astral Odyssey",
        desc: "Sebuah perjalanan melintasi ruang dimensi sejajar dengan kombinasi neon pink ultraviolet.",
        img: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
        cat: "3D Art",
        tags: "Space, Galaxy, Pink, Light"
      },
      {
        title: "Cybernetic Oasis",
        desc: "Konsep UI dasbor untuk aplikasi ekosistem tanaman pintar futuristik.",
        img: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=800",
        cat: "UI/UX",
        tags: "Futuristic, Dashboard, Greens"
      },
      {
        title: "Ethereal Chronos",
        desc: "Visualisasi jam digital berputar di atas gurun pasir kuarsa.",
        img: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=800",
        cat: "Ilustrasi",
        tags: "Sky, Matte, Desert, Time"
      }
    ];

    const randomPick = defaultMocks[Math.floor(Math.random() * defaultMocks.length)];
    setTitle(randomPick.title);
    setDescription(randomPick.desc);
    setCategory(randomPick.cat);
    setImagePreview(randomPick.img);
    setTagsInput(randomPick.tags);
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();

    if (!imagePreview) {
      alert("Harap pilih gambar karya atau klik 'Simulasi Karya' terlebih dahulu.");
      return;
    }
    if (!title.trim()) {
      alert("Judul karya tidak boleh kosong.");
      return;
    }

    const cleanTags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    onPublishArtwork({
      title,
      description: description || "Tidak ada deskripsi karya.",
      category,
      image: imagePreview,
      tags: cleanTags.length > 0 ? cleanTags : ['Digital', category],
      artist: {
        name: "Andra Ramadhan",
        avatar: userAvatar,
        role: "Lead Creative Designer"
      }
    });

    // Reset Form
    setTitle('');
    setDescription('');
    setImagePreview(null);
  };

  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#051424] text-slate-100 pb-28 scrollbar-none select-none">
      
      {/* 1. Header (Same as profile header) */}
      <div className="sticky top-0 w-full px-5 py-3 bg-[#051424]/85 backdrop-blur-md border-b border-white/5 z-20 flex justify-between items-center bg-slate-950/40">
        <div className="flex items-center gap-3">
          <button className="text-slate-300 hover:text-white transition-all">
            <Menu className="w-5.5 h-5.5" />
          </button>
          <span className="font-extrabold text-xl bg-gradient-to-r from-violet-400 to-fuchsia-300 bg-clip-text text-transparent">
            Artlink
          </span>
        </div>
        
        <div className="w-8 h-8 rounded-full border border-violet-500/50 overflow-hidden bg-slate-800">
          <img 
            src={userAvatar} 
            alt="User Avatar" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      <div className="px-5 pt-6">
        
        {/* Title Content */}
        <div className="mb-4">
          <h2 className="text-xl font-extrabold tracking-tight text-white mb-1.5 flex items-center gap-2">
            Unggah Karya
            <Sparkles className="w-4 h-4 text-violet-400 animate-pulse" />
          </h2>
          <p className="text-xs text-slate-400 font-normal leading-relaxed">
            Bagikan visi kreatif Anda dengan komunitas kolektor eksklusif kami.
          </p>
        </div>

        {/* 2. Drag & Drop Upload Container */}
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-3xl p-6 mb-5 flex flex-col items-center justify-center text-center transition-all min-h-[220px] ${
            isDragging 
              ? 'border-violet-500 bg-violet-600/10' 
              : imagePreview 
                ? 'border-emerald-500/50 bg-[#122131]/30' 
                : 'border-white/10 bg-[#122131]/40'
          }`}
        >
          {imagePreview ? (
            /* Upload Preview Box */
            <div className="w-full h-full flex flex-col items-center relative py-2">
              <div className="w-36 aspect-video rounded-xl overflow-hidden border border-emerald-500/30 mb-3 shadow-lg relative">
                <img 
                  src={imagePreview} 
                  alt="Preview" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <p className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Gambar Siap Dipublikasikan!
              </p>
              
              <div className="flex gap-2.5 mt-3">
                <button
                  type="button"
                  onClick={handleSelectFileClick}
                  className="text-[10px] font-bold text-violet-300 hover:text-white underline"
                >
                  Ganti Gambar
                </button>
                <button
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="text-[10px] font-bold text-rose-400 hover:text-rose-500 flex items-center gap-0.5"
                >
                  <Trash2 className="w-3 h-3" /> Hapus
                </button>
              </div>
            </div>
          ) : (
            /* Blank Upload Canvas */
            <>
              <div className="w-12 h-12 rounded-full bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mb-3 text-violet-400">
                <UploadCloud className="w-6 h-6" />
              </div>
              <h3 className="text-xs font-bold text-white mb-1">Tarik & Lepas Gambar</h3>
              <p className="text-[10px] text-slate-500 max-w-[220px] mb-4.5">
                Format yang didukung: JPG, PNG, GIF (Maks. 10MB)
              </p>
              
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectFileClick}
                  className="px-4 py-2 border border-white/15 bg-white/5 hover:bg-white/10 active:scale-95 text-[10px] font-bold tracking-wide rounded-full text-slate-200 transition-all cursor-pointer"
                >
                  Pilih File
                </button>
                
                <span className="text-[10px] text-slate-600 font-bold uppercase py-1">Atau</span>
                
                <button
                  type="button"
                  onClick={handleSimulateArt}
                  className="px-4 py-2 border border-violet-500/30 bg-violet-600/10 hover:bg-violet-600/20 active:scale-95 text-[10px] font-bold tracking-wide rounded-full text-violet-300 transition-all cursor-pointer flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-violet-400 animate-bounce" />
                  Simulasi Karya
                </button>
              </div>
            </>
          )}

          {/* Hidden HTML input file */}
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
        </div>

        {/* 3. Inputs Form */}
        <form onSubmit={handlePublish} className="space-y-4">
          
          {/* Title */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5 pl-1">
              JUDUL KARYA
            </label>
            <input
              id="upload-title-input"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Masukkan judul yang menarik..."
              className="w-full bg-[#122131]/60 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white placeholder-slate-500 font-medium focus:outline-none focus:border-violet-500/60 transition-all"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5 pl-1">
              DESKRIPSI
            </label>
            <textarea
              id="upload-desc-input"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ceritakan kisah di balik karya ini..."
              rows={3}
              className="w-full bg-[#122131]/60 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white placeholder-slate-500 font-medium focus:outline-none focus:border-violet-500/60 transition-all resize-none"
            />
          </div>

          {/* Category Dropdown */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5 pl-1">
              KATEGORI
            </label>
            <div className="relative">
              <select
                id="upload-category-input"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#122131]/80 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white appearance-none focus:outline-none focus:border-violet-500/60 cursor-pointer"
              >
                <option value="UI/UX" className="bg-[#051424]">UI/UX Design</option>
                <option value="Logo" className="bg-[#051424]">Logo & Branding</option>
                <option value="Branding" className="bg-[#051424]">Corporate Identity</option>
                <option value="3D Art" className="bg-[#051424]">Seni Digital 3D</option>
                <option value="Ilustrasi" className="bg-[#051424]">Ilustrasi Vektor</option>
              </select>
              <div className="absolute right-4 top-[15px] pointer-events-none text-slate-500">
                <ChevronDown className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Optional tags */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5 pl-1">
              TAGAR (PISAH DENGAN KOMA)
            </label>
            <input
              id="upload-tags-input"
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Figma, Blender, Minimalis"
              className="w-full bg-[#122131]/60 border border-white/10 rounded-2xl px-4 py-3.5 text-xs text-white placeholder-slate-500 font-medium focus:outline-none focus:border-violet-500/60 transition-all"
            />
          </div>

          {/* Publish Trigger Button */}
          <button
            type="submit"
            className="w-full py-4 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-extrabold text-xs tracking-wider shadow-lg shadow-violet-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer pt-3"
          >
            Publish
          </button>
          
          <button
            type="button"
            onClick={() => alert("Karya berhasil disimpan sebagai draft di penyimpanan lokal Anda.")}
            className="w-full py-1 text-[11px] text-center font-bold tracking-wide text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            Simpan Sebagai Draft
          </button>
        </form>

      </div>
    </div>
  );
}
