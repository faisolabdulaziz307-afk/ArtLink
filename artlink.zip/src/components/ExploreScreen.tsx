import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Heart, Eye, ArrowRight, MessageSquare, Tag, X, Menu, Share2 } from 'lucide-react';
import { Artwork } from '../types';
import { CATEGORIES } from '../data';

interface ExploreScreenProps {
  artworks: Artwork[];
  setArtworks: React.Dispatch<React.SetStateAction<Artwork[]>>;
  onGoToProfile: () => void;
  userAvatar: string;
}

export default function ExploreScreen({ artworks, setArtworks, onGoToProfile, userAvatar }: ExploreScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('Semua');
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  const [newComment, setNewComment] = useState('');
  const [commentsByArt, setCommentsByArt] = useState<Record<string, Array<{ user: string; text: string; date: string }>>>({
    '1': [
      { user: 'Soni_Desain', text: 'Gila! Reflek material neonnya dapet banget bro!', date: '1 jam yang lalu' },
      { user: 'Fitri_UX', text: 'Modern banget, suka fluid shapenya.', date: '30 menit yang lalu' }
    ],
    '4': [
      { user: 'Kreator_Nusantara', text: 'Layout masa depannya luar biasa rapi. Inspirasi baru!', date: '6 jam yang lalu' }
    ]
  });

  // Filter artworks based on Search and Selected Category
  const filteredArtworks = useMemo(() => {
    return artworks.filter(art => {
      const matchesCategory = activeCategory === 'Semua' || art.category === activeCategory;
      const matchesSearch = art.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            art.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            art.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [artworks, activeCategory, searchQuery]);

  // Handle Double Tap or Heart Click
  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setArtworks(prev => prev.map(art => {
      if (art.id === id) {
        return {
          ...art,
          liked: !art.liked,
          likes: art.liked ? art.likes - 1 : art.likes + 1
        };
      }
      return art;
    }));

    // Update state inside active detail modal as well if open
    if (selectedArtwork && selectedArtwork.id === id) {
      setSelectedArtwork(prev => {
        if (!prev) return null;
        return {
          ...prev,
          liked: !prev.liked,
          likes: prev.liked ? prev.likes - 1 : prev.likes + 1
        };
      });
    }
  };

  const handleAddComment = (artId: string) => {
    if (!newComment.trim()) return;
    const item = {
      user: 'Pengunjung_Kreatif',
      text: newComment,
      date: 'Baru saja'
    };
    setCommentsByArt(prev => ({
      ...prev,
      [artId]: [...(prev[artId] || []), item]
    }));
    setNewComment('');
  };

  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#051424] text-slate-100 pb-24 scrollbar-none select-none">
      
      {/* Background Soft Purple Glow */}
      <div className="absolute top-1/4 right-0 w-36 h-36 bg-violet-600/10 rounded-full blur-[60px] pointer-events-none"></div>
      
      {/* 1. Header (Menu, Artlink Brand, User profile shortcut) */}
      <div className="sticky top-0 w-full px-5 py-3 bg-[#051424]/80 backdrop-blur-md border-b border-white/5 z-20 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <button className="text-slate-300 hover:text-white transition-colors">
            <Menu className="w-5.5 h-5.5" />
          </button>
          <span className="font-extrabold text-xl bg-gradient-to-r from-violet-400 to-fuchsia-300 bg-clip-text text-transparent">
            Artlink
          </span>
        </div>
        
        {/* Clickable user profile avatar shortcut */}
        <button 
          onClick={onGoToProfile}
          className="focus:outline-none hover:scale-105 active:scale-95 transition-transform"
        >
          <div className="w-8 h-8 rounded-full border border-violet-500/50 overflow-hidden bg-slate-800 flex justify-center items-center">
            <img 
              src={userAvatar} 
              alt="Avatar" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </button>
      </div>

      {/* Main Container */}
      <div className="px-5 pt-4">
        
        {/* 2. Brand search bar */}
        <div className="relative mb-4">
          <input
            id="artwork-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari inspirasi..."
            className="w-full h-11 bg-[#122131]/60 backdrop-blur border border-white/10 rounded-2xl pl-10 pr-10 text-xs text-white placeholder-slate-500 font-medium focus:outline-none focus:border-violet-500/60"
          />
          <Search className="absolute left-3.5 top-[14px] w-4 h-4 text-slate-500" />
          <button 
            onClick={() => alert("Kriteria filter lanjutan disimulasikan.")}
            className="absolute right-3.5 top-[13px] text-slate-400 hover:text-white"
          >
            <SlidersHorizontal className="w-4 h-4 text-slate-500 hover:text-violet-400 transition-colors" />
          </button>
        </div>

        {/* 3. Horizontal category pills scroll */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-none w-full whitespace-nowrap">
          {CATEGORIES.map((cat) => {
            const isSelected = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                  isSelected 
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30 font-extrabold' 
                    : 'bg-[#122131]/50 border border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* 4. Portfolio listing Feed block (vertical listing) */}
        {filteredArtworks.length === 0 ? (
          <div className="py-16 text-center text-slate-500">
            <p className="text-sm font-semibold mb-1">Karya tidak ditemukan</p>
            <p className="text-xs">Ubah kata kunci pencarian atau kategori Anda.</p>
          </div>
        ) : (
          <div className="space-y-5">
            {filteredArtworks.map((art) => (
              <div
                key={art.id}
                onClick={() => setSelectedArtwork(art)}
                className="group relative bg-[#122131]/40 rounded-3xl overflow-hidden border border-white/[0.08] hover:border-violet-500/20 shadow-xl transition-all duration-350 cursor-pointer hover:shadow-2xl hover:shadow-violet-600/5 hover:-translate-y-0.5"
              >
                {/* Large 4:3 or variable height artwork preview */}
                <div className="aspect-[4/3] w-full overflow-hidden relative bg-slate-950">
                  <img
                    src={art.image}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Category capsule overlay */}
                  <div className="absolute top-4 right-4 bg-slate-950/70 backdrop-blur-md px-3.5 py-1 rounded-full border border-white/10 text-[9px] font-bold text-violet-300 tracking-wide uppercase">
                    {art.category}
                  </div>

                  {/* Dark transparent bottom gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/10 to-transparent"></div>
                  
                  {/* Text on top of Image at bottom left */}
                  <div className="absolute bottom-4 left-4 right-16">
                    <h3 className="text-base font-extrabold text-white tracking-tight leading-tight mb-1">
                      {art.title}
                    </h3>
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full overflow-hidden border border-white/20">
                        <img 
                          src={art.artist.avatar} 
                          alt={art.artist.name} 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <span className="text-[10px] text-slate-300 font-medium">
                        Oleh {art.artist.name}
                      </span>
                    </div>
                  </div>

                  {/* Love Interactive button on bottom right */}
                  <button
                    onClick={(e) => handleLike(art.id, e)}
                    className="absolute bottom-4 right-4 w-9 h-9 rounded-full bg-slate-900/80 backdrop-blur border border-white/10 flex items-center justify-center transition-all hover:scale-110 active:scale-90"
                  >
                    <Heart 
                      className={`w-4 h-4 transition-colors ${
                        art.liked 
                          ? 'fill-rose-500 text-rose-500' 
                          : 'text-slate-300 hover:text-white'
                      }`} 
                    />
                  </button>
                </div>

                {/* Optional mini quick detail info */}
                <div className="px-4 py-3 bg-slate-900/30 flex justify-between items-center border-t border-white/5 text-[10px] text-slate-500">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-slate-500" /> {art.likes} Suka
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-slate-500" /> {art.views} Dilihat
                    </span>
                  </div>
                  <span>{art.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* --- BIG DETAILED OVERLAY MODAL FOR ARTWORK --- */}
      {selectedArtwork && (
        <div className="absolute inset-0 bg-[#020617]/90 backdrop-blur-md z-50 flex items-end">
          
          <div className="w-full max-h-[92%] bg-[#0d1624] border-t border-white/10 rounded-t-[36px] flex flex-col overflow-y-auto select-none pb-12 scrollbar-none transform transition-transform duration-300">
            
            {/* Header control */}
            <div className="sticky top-0.5 inset-x-0 h-14 px-6 bg-[#0d1624] flex items-center justify-between border-b border-white/5 z-30">
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#ccc3d8]">Detail Karya Portofolio</span>
              <button 
                onClick={() => setSelectedArtwork(null)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4.5 h-4.5 text-slate-300" />
              </button>
            </div>

            {/* Core Artwork Display */}
            <div className="w-full relative aspect-video bg-neutral-950 shrink-0">
              <img 
                src={selectedArtwork.image} 
                alt={selectedArtwork.title} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 right-4 bg-violet-600 text-white font-extrabold text-[10px] uppercase px-3.5 py-1.5 rounded-full border border-violet-400">
                {selectedArtwork.category}
              </div>
            </div>

            {/* Body Info */}
            <div className="p-6 space-y-5">
              
              {/* Title & Stats */}
              <div className="flex justify-between items-start gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight leading-tight">
                    {selectedArtwork.title}
                  </h2>
                  <p className="text-[11px] text-slate-500 mt-0.5">Dirilis {selectedArtwork.timestamp}</p>
                </div>
                
                {/* Big Interactive Like Option */}
                <button
                  onClick={(e) => handleLike(selectedArtwork.id, e)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold"
                >
                  <Heart className={`w-4 h-4 ${selectedArtwork.liked ? 'fill-rose-500 text-rose-500' : 'text-slate-400'}`} />
                  {selectedArtwork.likes}
                </button>
              </div>

              {/* Artist Segment */}
              <div className="p-3 bg-slate-900/60 rounded-2xl border border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img 
                    src={selectedArtwork.artist.avatar} 
                    alt={selectedArtwork.artist.name} 
                    className="w-9 h-9 rounded-full object-cover border border-violet-500/30"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-white">{selectedArtwork.artist.name}</h4>
                    <p className="text-[10px] text-slate-400">{selectedArtwork.artist.role}</p>
                  </div>
                </div>
                {selectedArtwork.artist.name === "Andra Ramadhan" && (
                  <button 
                    onClick={() => {
                      setSelectedArtwork(null);
                      onGoToProfile();
                    }}
                    className="text-[10px] font-bold text-violet-400 hover:underline flex items-center gap-0.5"
                  >
                    Lihat Profil <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Description body */}
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Deskripsi Karya</p>
                <p className="text-xs text-slate-300 leading-relaxed font-normal">
                  {selectedArtwork.description}
                </p>
              </div>

              {/* Tags bullet points list */}
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Tagar</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedArtwork.tags.map(tag => (
                    <span key={tag} className="flex items-center gap-1 px-2.5 py-1 bg-[#122131] rounded-lg text-[10px] font-medium text-slate-300 border border-white/5">
                      <Tag className="w-2.5 h-2.5 text-violet-400" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Review & Live simulated comments feedback */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">
                    Komentar Komunitas ({commentsByArt[selectedArtwork.id]?.length || 0})
                  </p>
                  <span className="text-[10px] text-violet-400 font-semibold">Moderasi Aktif</span>
                </div>

                {/* Comment box items */}
                <div className="space-y-2.5">
                  {(commentsByArt[selectedArtwork.id] || []).map((c, i) => (
                    <div key={i} className="p-3 bg-[#122131]/50 border border-white/5 rounded-2xl text-xs space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="font-extrabold text-violet-300 text-[10px]">@{c.user}</span>
                        <span className="text-[9px] text-slate-500">{c.date}</span>
                      </div>
                      <p className="text-slate-300 leading-normal text-xs">{c.text}</p>
                    </div>
                  ))}
                  
                  {!(commentsByArt[selectedArtwork.id]?.length) && (
                    <p className="text-[11px] text-slate-500 text-center py-2">Belum ada komentar. Jadilah yang pertama memberikan apresiasi!</p>
                  )}
                </div>

                {/* User write comment block */}
                <div className="pt-2 flex items-center gap-2">
                  <input 
                    type="text" 
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Beri apresiasi atau masukan..."
                    onKeyDown={(e) => e.key === 'Enter' && handleAddComment(selectedArtwork.id)}
                    className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs placeholder-slate-500 focus:outline-none focus:border-violet-500/60"
                  />
                  <button 
                    onClick={() => handleAddComment(selectedArtwork.id)}
                    className="px-4 py-2 bg-violet-600 hover:bg-violet-500 rounded-xl text-xs font-bold text-white tracking-wide"
                  >
                    Kirim
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
