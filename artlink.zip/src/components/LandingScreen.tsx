import { ArrowRight, Compass, LogIn, Award, Sparkles, Zap } from 'lucide-react';
import etherealInterface from '../assets/images/ethereal_interface_1779780082409.png';
import vortexNeon from '../assets/images/vortex_neon_1779780101211.png';

interface LandingScreenProps {
  onEnterExplore: () => void;
  onEnterLogin: () => void;
}

export default function LandingScreen({ onEnterExplore, onEnterLogin }: LandingScreenProps) {
  return (
    <div className="absolute inset-0 overflow-y-auto bg-[#051424] text-slate-100 pb-12 scrollbar-none select-none">
      
      {/* Immersive Blur Circle Backdrop */}
      <div className="absolute top-10 left-10 w-44 h-44 bg-violet-600/20 rounded-full blur-[60px] pointer-events-none"></div>
      <div className="absolute bottom-20 right-5 w-52 h-52 bg-indigo-500/20 rounded-full blur-[80px] pointer-events-none"></div>

      {/* Dynamic Header */}
      <div className="sticky top-0 w-full px-6 py-4 flex items-center justify-between bg-[#051424]/60 backdrop-blur-md border-b border-white/5 z-20">
        <div className="flex items-center gap-1.5">
          <span className="font-black text-xl bg-gradient-to-r from-violet-400 via-fuchsia-300 to-indigo-300 bg-clip-text text-transparent">
            Artlink
          </span>
        </div>
        <button 
          onClick={onEnterLogin}
          className="flex items-center gap-1 px-4 py-1.5 bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-xs font-semibold rounded-full text-violet-300 transition-all cursor-pointer"
        >
          <LogIn className="w-3 h-3 text-violet-400" />
          Masuk
        </button>
      </div>

      <div className="px-6 pt-6 flex flex-col items-center">
        {/* Sparkle badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-violet-500/10 border border-violet-400/20 rounded-full text-[10px] font-bold text-violet-300 uppercase tracking-widest mb-4">
          <Sparkles className="w-3 h-3 text-violet-400 animate-pulse" />
          Gateway Kreator Unggulan
        </div>

        {/* Hero Copy */}
        <h2 className="text-2xl font-black text-center tracking-tight leading-tight max-w-[320px] mb-3">
          Sinergi Kreatif <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-indigo-400 bg-clip-text text-transparent">Tanpa Batas</span>
        </h2>
        
        <p className="text-slate-400 text-center text-xs leading-relaxed max-w-[290px] mb-6">
          Hubungkan karya digital terkurasi Anda dengan kolektor, desainer, dan seniman global terbaik nusantara.
        </p>

        {/* Floating Stack Showcase Card (Ethereal Interface inside phone) */}
        <div className="relative w-full max-w-[280px] h-[190px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl mb-8 group transition-transform duration-500 hover:scale-[1.03]">
          <img 
            src={etherealInterface} 
            alt="Ethereal showcase"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
            <span className="text-[10px] font-extrabold text-violet-400 uppercase tracking-wider mb-0.5">TERIKAT & TERKURASI</span>
            <h3 className="font-bold text-sm text-white">Ethereal Os Interface</h3>
            <p className="text-[10px] text-slate-300">Oleh desainer Andra Ramadhan</p>
          </div>
          
          {/* Side peeking miniature tag */}
          <div className="absolute top-3 right-3 px-2 py-0.5 bg-black/60 backdrop-blur text-[8px] font-bold tracking-wider text-amber-400 rounded-full border border-amber-500/30">
            ★ FEATURED
          </div>
        </div>

        {/* Micro Stats Section */}
        <div className="grid grid-cols-3 gap-3 w-full bg-slate-900/40 backdrop-blur border border-white/5 p-4 rounded-2xl mb-8">
          <div className="text-center">
            <div className="text-base font-extrabold text-violet-300 leading-tight">12.4K</div>
            <div className="text-[9px] font-semibold text-slate-500 tracking-wider uppercase mt-1">Desainer</div>
          </div>
          <div className="text-center border-x border-white/5">
            <div className="text-base font-extrabold text-violet-300 leading-tight">89.1K</div>
            <div className="text-[9px] font-semibold text-slate-500 tracking-wider uppercase mt-1">Karya Seni</div>
          </div>
          <div className="text-center">
            <div className="text-base font-extrabold text-[#ede0ff] leading-tight">Rp0%</div>
            <div className="text-[9px] font-semibold text-slate-500 tracking-wider uppercase mt-1">Biaya Komisi</div>
          </div>
        </div>

        {/* Main call to actions */}
        <div className="w-full flex flex-col gap-3">
          <button
            onClick={onEnterExplore}
            className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wide shadow-lg shadow-violet-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Compass className="w-4 h-4 text-violet-200" />
            Mulai Jelajah Karya
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          
          <button
            onClick={onEnterLogin}
            className="w-full py-3.5 px-6 rounded-full bg-slate-900/50 hover:bg-slate-900/80 text-violet-300 hover:text-white font-bold text-xs tracking-wide border border-violet-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-violet-400" />
            Masuk Sekarang (Login)
          </button>
        </div>

        {/* Feature Icons Section */}
        <div className="mt-8 flex items-center gap-5 justify-center opacity-80 hover:opacity-100 transition-opacity">
          <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-medium">
            <Award className="w-3.5 h-3.5 text-amber-400" /> Secure Payments
          </div>
          <div className="w-1 h-1 bg-slate-700 rounded-full"></div>
          <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-medium">
            <Zap className="w-3.5 h-3.5 text-indigo-400" /> Top Commissions
          </div>
        </div>

      </div>
    </div>
  );
}
