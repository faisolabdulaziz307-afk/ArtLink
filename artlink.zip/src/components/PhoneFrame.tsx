import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, Signal, Battery, RefreshCw, Volume2, Shield } from 'lucide-react';

interface PhoneFrameProps {
  children: React.ReactNode;
  onReset: () => void;
}

export default function PhoneFrame({ children, onReset }: PhoneFrameProps) {
  const [time, setTime] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState(98);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false }));
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);

    // Slowly reduce battery just for fun realism
    const batteryTimer = setInterval(() => {
      setBatteryLevel(prev => (prev > 5 ? prev - 1 : 98));
    }, 60000);

    return () => {
      clearInterval(timer);
      clearInterval(batteryTimer);
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-2 sm:p-6 md:p-8 transition-all duration-500 overflow-x-hidden"
         style={{
           backgroundImage: 'radial-gradient(circle at 50% 20%, #1e133e 0%, #050b14 70%)'
         }}>
      
      {/* Dev Header Info Bar */}
      <div className="w-full max-w-5xl mb-6 flex flex-col md:flex-row items-center justify-between gap-4 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-violet-600/20 border border-violet-500/30 rounded-2xl">
            <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-violet-400 to-fuchsia-300 bg-clip-text text-transparent">AL</span>
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight flex items-center gap-2">
              Artlink Prototype 
              <span className="text-[10px] uppercase tracking-wider font-semibold bg-violet-500/20 text-violet-300 px-2 py-0.5 rounded-full border border-violet-400/20">
                v1.2 Live
              </span>
            </h1>
            <p className="text-xs text-slate-400">Desain Premium & Portofolio Kreator Nusantara</p>
          </div>
        </div>

        {/* Floating Controls to Switch Presentation Mode */}
        <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-full border border-slate-800 shadow-xl">
          <button
            onClick={() => setIsFullscreen(false)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              !isFullscreen 
                ? 'bg-violet-600/90 text-white shadow-md' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Mode iPhone 15
          </button>
          <button
            onClick={() => setIsFullscreen(true)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              isFullscreen 
                ? 'bg-violet-600/90 text-white shadow-md' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Mode Tablet / Desktop
          </button>
          
          <div className="w-px h-4 bg-slate-800 mx-1"></div>
          
          <button
            onClick={onReset}
            title="Reset Aplikasi"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 rounded-full transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {isFullscreen ? (
        /* Wide Presentation View */
        <div className="w-full max-w-5xl rounded-3xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl relative flex flex-col"
             style={{ height: '820px' }}>
          {/* Header simulated interface for desktop */}
          <div className="px-6 py-3.5 bg-slate-900/60 backdrop-blur border-b border-rose-500/10 flex justify-between items-center text-slate-300">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
              <span className="text-xs text-slate-400 ml-2 font-mono">artlink.framer.app</span>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="text-emerald-400 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" /> Terkoneksi Aman
              </span>
              <span>UTC {time}</span>
            </div>
          </div>
          <div className="flex-1 overflow-hidden relative">
            {children}
          </div>
        </div>
      ) : (
        /* Portrait iPhone Frame View */
        <div className="relative mx-auto transition-all duration-300 w-[393px] h-[852px] shrink-0 rounded-[55px] shadow-[0_0_80px_rgba(124,58,237,0.15)] select-none">
          {/* Deep Shadow Outer Ring */}
          <div className="absolute inset-0 rounded-[55px] border-[12px] border-slate-900 shadow-[inset_0_2px_12px_rgba(255,255,255,0.08),_0_25px_50px_-12px_rgba(0,0,0,0.8)] z-30 pointer-events-none"></div>
          
          {/* Thin Inner Golden/Metal Accent Ring */}
          <div className="absolute inset-[11px] rounded-[44px] border border-slate-800 z-20 pointer-events-none"></div>

          {/* Simulated hardware side buttons */}
          <div className="absolute -left-1.5 top-28 w-1.5 h-10 bg-slate-800 rounded-l shadow z-10"></div>
          <div className="absolute -left-1.5 top-44 w-1.5 h-16 bg-slate-800 rounded-l shadow z-10"></div>
          <div className="absolute -left-1.5 top-64 w-1.5 h-16 bg-slate-800 rounded-l shadow z-10"></div>
          <div className="absolute -right-1.5 top-44 w-1.5 h-20 bg-slate-800 rounded-r shadow z-10"></div>

          {/* Phone Inner screen body */}
          <div className="absolute inset-[12px] rounded-[43px] overflow-hidden bg-slate-950 flex flex-col z-10">
            
            {/* Elegant Dynamic Island Top Bar */}
            <div className="absolute top-0 inset-x-0 h-11 px-7 flex items-center justify-between text-white text-[13px] font-semibold tracking-tight z-40 select-none bg-slate-950/20 backdrop-blur-xs">
              <span className="font-medium text-slate-100">{time}</span>
              
              {/* Complex Pill notch simulator */}
              <div className="absolute left-[50%] -translate-x-[50%] top-2 w-[110px] h-[30px] bg-black rounded-3xl flex items-center justify-end px-3 gap-1 shadow-md pointer-events-auto transition-all hover:w-[130px] group">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse hidden group-hover:block"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center">
                  <div className="w-1 h-1 rounded-full bg-indigo-700"></div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-slate-100">
                <Signal className="w-3.5 h-3.5 shrink-0" />
                <Wifi className="w-3.5 h-3.5 shrink-0" />
                <div className="flex items-center gap-0.5 ml-0.5">
                  <span className="text-[10px] text-slate-300 font-mono font-medium">{batteryLevel}%</span>
                  <Battery className="w-4 h-4 shrink-0 text-slate-100" />
                </div>
              </div>
            </div>

            {/* Content view with safe offset at the top */}
            <div className="flex-1 w-full h-full relative overflow-hidden bg-[#051424] pt-11">
              {children}
            </div>

            {/* Apple Home Indicator Bar */}
            <div className="absolute bottom-1 bg-slate-950/20 pointer-events-none inset-x-0 h-8 flex items-center justify-center z-40">
              <div className="w-32 h-1 bg-slate-300/60 rounded-full"></div>
            </div>

          </div>
        </div>
      )}

      {/* Under Frame Tips */}
      <p className="text-[11px] text-slate-500 mt-5 text-center font-medium opacity-85 hover:opacity-100 cursor-default">
        ⚡ Prototipe interaktif sepenuhnya. Klik <b>Datar/Kategori</b>, beri <b>Like ♡</b>, kirim pesan <b>Hubungi Desainer</b>, atau <b>Unggah File</b> Anda!
      </p>
    </div>
  );
}
