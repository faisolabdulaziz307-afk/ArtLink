import React, { useState, useEffect } from 'react';
import PhoneFrame from './components/PhoneFrame';
import BottomNavbar from './components/BottomNavbar';

// Core Screens
import LandingScreen from './components/LandingScreen';
import LoginScreen from './components/LoginScreen';
import ExploreScreen from './components/ExploreScreen';
import ProfileScreen from './components/ProfileScreen';
import UploadScreen from './components/UploadScreen';

// Mock Data & System structure
import { INITIAL_ARTWORKS, ARTIST_ANDRA } from './data';
import { Artwork } from './types';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'login' | 'explore' | 'profile' | 'upload'>('landing');
  const [artworks, setArtworks] = useState<Artwork[]>(INITIAL_ARTWORKS);
  const [currentUser, setCurrentUser] = useState<{ email: string; avatar: string; name: string } | null>(null);
  
  // High fidelity visual toast banner state
  const [toast, setToast] = useState<{ message: string; visible: boolean } | null>(null);

  // Trigger temporary notification
  const handleShowToast = (msg: string) => {
    setToast({ message: msg, visible: true });
  };

  useEffect(() => {
    if (toast && toast.visible) {
      const timer = setTimeout(() => {
        setToast(prev => prev ? { ...prev, visible: false } : null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Handle Simulated Login success redirection
  const handleLoginSuccess = (email: string) => {
    const defaultName = email.split('@')[0];
    const capitalized = defaultName.charAt(0).toUpperCase() + defaultName.slice(1);
    
    setCurrentUser({
      email,
      name: capitalized,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150" // High quality generic user
    });

    handleShowToast(`Selamat datang kembali, ${capitalized}! Berhasil masuk ke Artlink.`);
    setCurrentPage('explore');
  };

  // Handle Simulated Publish creation
  const handlePublishArtwork = (newArt: Omit<Artwork, 'id' | 'likes' | 'liked' | 'views' | 'timestamp'>) => {
    const newlyCreated: Artwork = {
      ...newArt,
      id: (artworks.length + 1).toString(),
      likes: 0,
      liked: false,
      views: 12,
      timestamp: "Baru saja"
    };

    setArtworks(prev => [newlyCreated, ...prev]);
    handleShowToast(`Karya "${newArt.title}" berhasil dipublikasikan di feed Artlink!`);
    setCurrentPage('explore');
  };

  // Handle simulated logout or reload
  const handleResetApp = () => {
    setCurrentPage('landing');
    setArtworks(INITIAL_ARTWORKS);
    setCurrentUser(null);
    handleShowToast("Aplikasi berhasil direset ke status awal.");
  };

  const activeAvatar = currentUser ? currentUser.avatar : ARTIST_ANDRA.avatar;

  return (
    <PhoneFrame onReset={handleResetApp}>
      
      {/* 1. Core Page Navigation Routing */}
      {currentPage === 'landing' && (
        <LandingScreen 
          onEnterExplore={() => {
            handleShowToast("Masuk sebagai Pengunjung Tamu terkurasi.");
            setCurrentPage('explore');
          }}
          onEnterLogin={() => setCurrentPage('login')}
        />
      )}

      {currentPage === 'login' && (
        <LoginScreen 
          onLoginSuccess={handleLoginSuccess}
          onBackToLanding={() => setCurrentPage('landing')}
        />
      )}

      {currentPage === 'explore' && (
        <ExploreScreen 
          artworks={artworks}
          setArtworks={setArtworks}
          onGoToProfile={() => setCurrentPage('profile')}
          userAvatar={activeAvatar}
        />
      )}

      {currentPage === 'profile' && (
        <ProfileScreen 
          designer={ARTIST_ANDRA}
          artworks={artworks}
          onArtClick={(artwork) => {
            // Force temporary redirection back to explore with state modal selected in higher fidelity
            setCurrentPage('explore');
            // Timeout allows the screen to mount before triggering child select simulation
            setTimeout(() => {
              const exploreEl = document.querySelector(`[alt="${artwork.title}"]`);
              if (exploreEl) {
                // Trigger simulated click
                (exploreEl.closest('.cursor-pointer') as HTMLElement)?.click();
              }
            }, 100);
          }}
          onGoToExplore={() => setCurrentPage('explore')}
          onShowToast={handleShowToast}
        />
      )}

      {currentPage === 'upload' && (
        <UploadScreen 
          onPublishArtwork={handlePublishArtwork}
          userAvatar={activeAvatar}
        />
      )}

      {/* 2. Embedded Floating Bottom Navbar — Only visible inside standard functional tabs */}
      {(currentPage === 'explore' || currentPage === 'profile' || currentPage === 'upload') && (
        <BottomNavbar 
          currentTab={currentPage}
          setTab={(tab) => setCurrentPage(tab)}
          avatarUrl={activeAvatar}
        />
      )}

      {/* 3. Micro Premium Toast Glass Notification Overlay */}
      {toast && toast.visible && (
        <div className="absolute top-16 inset-x-4 bg-slate-900/90 backdrop-blur-xl border border-violet-500/30 rounded-2xl p-3.5 shadow-[0_10px_35px_rgba(124,58,237,0.3)] z-[60] flex items-center gap-3 animate-slide-down transform transition-all">
          <div className="w-8 h-8 rounded-full bg-violet-600/20 text-violet-400 border border-violet-400/20 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4.5 h-4.5 text-violet-300" />
          </div>
          <div>
            <p className="text-[11px] font-extrabold text-white leading-tight">Artlink Sistem</p>
            <p className="text-[10px] text-slate-300 font-medium leading-normal mt-0.5">{toast.message}</p>
          </div>
        </div>
      )}

    </PhoneFrame>
  );
}
