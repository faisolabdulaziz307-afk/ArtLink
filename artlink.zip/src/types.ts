export interface Artwork {
  id: string;
  title: string;
  artist: {
    name: string;
    avatar: string;
    role: string;
  };
  category: string;
  image: string;
  likes: number;
  liked: boolean;
  views: number;
  timestamp: string;
  description: string;
  tags: string[];
}

export interface Message {
  id: string;
  sender: 'user' | 'andra';
  text: string;
  timestamp: string;
}

export interface UserProfile {
  name: string;
  avatar: string;
  role: string;
  bio: string;
  tags: string[];
  isOnline: boolean;
  socials: {
    grid: string;
    dribbble: string;
    instagram: string;
    message: string;
  };
}
