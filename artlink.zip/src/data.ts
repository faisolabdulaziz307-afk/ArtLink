import { Artwork, UserProfile } from './types';

// Import our high-quality generated assets
import avatarAndra from './assets/images/avatar_andra_1779780060836.png';
import etherealInterface from './assets/images/ethereal_interface_1779780082409.png';
import nebulaCity from './assets/images/nebula_city_1779780143468.png';
import neonPrism from './assets/images/neon_prism_1779780124447.png';
import vortexNeon from './assets/images/vortex_neon_1779780101211.png';

export const ARTIST_ANDRA: UserProfile = {
  name: "Andra Ramadhan",
  avatar: avatarAndra,
  role: "Lead Creative Designer",
  bio: "Membangun pengalaman visual yang memikat dan fungsional untuk brand masa depan.",
  tags: ["UI DESIGNER", "ILLUSTRATOR", "3D ARTIST"],
  isOnline: true,
  socials: {
    grid: "https://dribbble.com",
    dribbble: "https://dribbble.com",
    instagram: "https://instagram.com",
    message: "andra@artlink.design"
  }
};

export const INITIAL_ARTWORKS: Artwork[] = [
  {
    id: "1",
    title: "Vortex Neon",
    artist: {
      name: "Andra Ramadhan",
      avatar: avatarAndra,
      role: "Lead Creative Designer"
    },
    category: "3D Art",
    image: vortexNeon,
    likes: 342,
    liked: false,
    views: 1205,
    timestamp: "2 jam yang lalu",
    description: "Eksplorasi organic liquid metaballs dengan efek kilau neon yang mencolok. Karya seni digital 3D ini melambangkan fusi antara teknologi modern dan keindahan alam organik yang terus berevolusi.",
    tags: ["3D Render", "Bio-Organic", "Fluid", "Neon Gradient"]
  },
  {
    id: "2",
    title: "Minimal Luxe",
    artist: {
      name: "Sabrina Putri",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
      role: "Product Designer"
    },
    category: "Logo",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800",
    likes: 189,
    liked: false,
    views: 948,
    timestamp: "1 hari yang lalu",
    description: "Pendekatan branding minimalis mewah pada arsitektur produk jam tangan modern. Menggabungkan tekstur batu tulis alam dengan elemen logam presisi tinggi.",
    tags: ["Branding", "Luxury", "Minimalist", "Watch Design"]
  },
  {
    id: "3",
    title: "Nebula City",
    artist: {
      name: "Andra Ramadhan",
      avatar: avatarAndra,
      role: "Lead Creative Designer"
    },
    category: "Ilustrasi",
    image: nebulaCity,
    likes: 512,
    liked: false,
    views: 2489,
    timestamp: "3 jam yang lalu",
    description: "Sebuah visi futuristik tentang kota kosmik dengan menara pencakar langit membentang tinggi menembus langit nebula berbintang. Menampilkan siluet pengelana kosmik yang memandang keabadian semesta.",
    tags: ["Sci-Fi", "Synthwave", "Matte Painting", "Cosmic Art"]
  },
  {
    id: "4",
    title: "Ethereal Interface",
    artist: {
      name: "Andra Ramadhan",
      avatar: avatarAndra,
      role: "Lead Creative Designer"
    },
    category: "UI/UX",
    image: etherealInterface,
    likes: 829,
    liked: false,
    views: 3102,
    timestamp: "12 jam yang lalu",
    description: "Sebuah konsep visual antarmuka sistem operasi masa depan dengan simulasi fluida dan gaya kaca transparan yang melengkung indah. Menu dinamis bergaya glassmorphism premium.",
    tags: ["UI/UX", "Glassmorphism", "Liquid Design", "SaaS Concept"]
  },
  {
    id: "5",
    title: "Neon Prism",
    artist: {
      name: "Andra Ramadhan",
      avatar: avatarAndra,
      role: "Lead Creative Designer"
    },
    category: "3D Art",
    image: neonPrism,
    likes: 271,
    liked: false,
    views: 1120,
    timestamp: "1 hari yang lalu",
    description: "Instalasi geometri kubus kaca yang berkilau memantulkan spektrum cahaya oranye menyala dan biru dingin. Menggali dimensi optik dan pembiasan cahaya holografik dalam dunia virtual.",
    tags: ["Geometric", "Chrystal", "Raytracing", "Holographic"]
  },
  {
    id: "6",
    title: "Celestial Identity",
    artist: {
      name: "Raka Wijaya",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
      role: "Identity Specialist"
    },
    category: "Branding",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
    likes: 198,
    liked: false,
    views: 840,
    timestamp: "3 hari yang lalu",
    description: "Proyek desain identitas visual bertema kosmik dan konstelasi bintang untuk studio inovasi antariksa internasional. Bermain dengan ilusi negatif dan motif bulat melingkar semesta.",
    tags: ["Corporate Brand", "Logo Design", "Pattern", "Vector"]
  }
];

export const MOCK_BOT_RESPONSES: string[] = [
  "Halo! Terima kasih sudah menghubungi saya. Ada yang bisa saya bantu dengan portofolio saya?",
  "Saya sangat tertarik untuk berkolaborasi dalam proyek UI/UX atau 3D Art Anda berikutnya! Berikan detail singkatnya ya.",
  "Terima kasih atas apresiasinya! Karya tersebut saya buat menggunakan Blender dan Figma selama kurang lebih 2 minggu.",
  "Tentu saja! Silakan bagikan ide desain Anda terlebih dahulu, dan mari kita wujudkan bersama di Artlink.",
  "Sesi konsultasi kreatif saya biasanya dibuka setiap akhir pekan. Apakah Anda ingin memesan waktu?"
];
export const CATEGORIES = ["Semua", "UI/UX", "Logo", "Branding", "3D Art", "Ilustrasi"];
